.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

drop view if exists tratadores;
drop trigger if exists tratadorSessao;
