.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

-- Assumindo que um ano tem 365 dias
-- 18 anos -> 6570 dias
create trigger if not exists validaIdadeFuncionario
before insert on Funcionario
for each row
begin
 select case
 when julianday('now') - julianday((select NEW.dataNascimento)) < 6570
 then raise(abort, 'Funcionario tem de ter mais de 18 anos.')
end;
end;
