.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

--estado inicial
select * from Alimentacao;

insert into Zoo
  values(
    0002,
    'Zoo de Santo Inácio',
    10000,
    3274,
    '227878500',
    'Rua 5 de Outubro',
    '4430-809',
    '10:00',
    '17:00',
    5,
    150000
);
insert into Animal
values (
  01,
  'Anabelle',
  3,
  'Alpaca',
  'Vicugna pacos',
  '23-04-2019',
  'Feminino',
  0002,
  NULL
  );
insert into Alimentacao
  values(
    001,
    'Carne',
    950
  );
  insert into QuantidadeNecessaria
    values(
      01,
      001,
      95
    );

--atualiza
select * from Alimentacao;
