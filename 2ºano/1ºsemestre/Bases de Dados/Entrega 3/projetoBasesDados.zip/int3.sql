.mode columns
.headers on
.nullvalue NULL

select idAnimal, (sum(cast(((strftime('%s',  horaFim) - strftime('%s', horaInicio))) as real))/3600) as "numHoras p/ dia"
from (select * from FuncionarioAnimalSessao join (SessaoHorarioSessao natural join HorarioSessao) using (idSessao))
group by idAnimal
order by "numHoras p/ dia";
