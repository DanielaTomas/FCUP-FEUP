.mode columns
.headers on
Pragma Foreign_Keys = on;

drop table if exists QuantidadeNecessaria;
drop table if exists AnimalHabitat;
drop table if exists FuncionarioAnimalSessao;
drop table if exists VisitanteZoo;
drop table if exists Habitat;
drop table if exists Alimentacao;
drop table if exists SessaoHorarioSessao;
drop table if exists HorarioSessao;
drop table if exists Sessao;
drop table if exists Funcionario;
drop table if exists Especialidade;
drop table if exists Animal;
drop table if exists Restaurante;
drop table if exists Hotel;
drop table if exists Servico;
drop table if exists Bilhete;
drop table if exists TipoBilhete;
drop table if exists Visitante;
drop table if exists Zoo;


create table Zoo(
  idZoo int PRIMARY KEY,
  nomeZoo text constraint nome_zoo_nn NOT NULL
               constraint nome_zoo_u UNIQUE,
  lotacaoMaxima int constraint lotacao_max_zoo_c CHECK(lotacaoMaxima >= 0),
  lotacaoAtual int constraint lotacao_atual_zoo_c CHECK(lotacaoAtual >= 0) default (0),
  numeroTelefone text constraint numero_telefone_zoo_nn NOT NULL
                      constraint numero_telefone_zoo_u UNIQUE
                      constraint numero_telefone_zoo_c CHECK(LENGTH (numeroTelefone = 9)),
  rua text constraint rua_zoo_nn NOT NULL,
  codigoPostal text,
  horaAbertura TIME,
  horaFecho TIME,
  numeroTotalAnimais int constraint numero_total_animais_zoo_c CHECK(numeroTotalAnimais >= 0),
  area int constraint area_c CHECK (area > 0),
  constraint horas_zoo_c CHECK (horaFecho > horaAbertura),
  constraint lotacao_zoo_c CHECK (lotacaoMaxima >= lotacaoAtual)
);

create table Visitante(
  nifVisitante text PRIMARY KEY constraint nif_visitante_c CHECK(LENGTH (nifVisitante = 9)),
  nome text constraint nome_visitante_nn NOT NULL,
  idade int constraint idade_visitante_nn NOT NULL,
  numeroTelefone text constraint numero_telefone_visitante_nn NOT NULL
                      constraint numero_telefone_visitante_u UNIQUE
                      constraint numero_telefone_visitante_c CHECK(LENGTH (numeroTelefone = 9))
);

create table TipoBilhete(
  idTipoBilhete int PRIMARY KEY,
  tipoBilhete text constraint tipo_bilhete_nn NOT NULL
);

create table Bilhete(
  codigo int PRIMARY KEY,
  horaEntrada TIME,
  dataBilhete DATE,
  preco float constraint preco_bilhete_c CHECK (preco >= 0),
  nifVisitante text constraint nif_visitante_bilhete_nn NOT NULL references Visitante ON DELETE CASCADE
                                                                                      ON UPDATE CASCADE,
  idTipoBilhete int constraint id_tipo_bilhete_bilhete_nn NOT NULL references TipoBilhete ON DELETE CASCADE
                                                                                          ON UPDATE CASCADE
);

create table Servico(
  idServico int PRIMARY KEY,
  nome text constraint nome_servico_nn NOT NULL,
  numeroTelefone text constraint numero_telefone_servico_nn NOT NULL
                      constraint numero_telefone_servico_u UNIQUE
                      constraint numero_telefone_servico_c CHECK (LENGTH (numeroTelefone = 9)),
  capacidade int default (50),
  email text,
  horaAbertura TIME,
  horaFecho TIME,
  rua text constraint rua_servico_nn NOT NULL,
  codigoPostal int,
  idZoo int constraint id_zoo_servico_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                 ON UPDATE CASCADE,
  constraint horas_servico_c CHECK (horaFecho > horaAbertura)
);

create table Hotel(
  idServico int constraint servico_hotel_nn NOT NULL PRIMARY KEY references Servico ON DELETE CASCADE
                                                                                    ON UPDATE CASCADE,
  preco float constraint preco_hotel_c CHECK (preco >= 0)
);

create table Restaurante(
  idServico int constraint id_servico_restaurante_nn NOT NULL PRIMARY KEY references Servico ON DELETE CASCADE
                                                                                             ON UPDATE CASCADE,
  tipoRestaurante text,
  preco float constraint preco_restaurante_c CHECK (preco >= 0)
);

create table Animal(
  idAnimal int PRIMARY KEY,
  nome text constraint nome_animal_nn NOT NULL,
  idade int,
  nomeComum text constraint nome_comum_animal_nn NOT NULL,
  nomeCientifico text constraint nome_cientifico_animal_nn NOT NULL,
  dataChegadaZoo DATE,
  genero text default ('Masculino'),
  idZoo int constraint id_zoo_animal_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                ON UPDATE CASCADE,
  idProgenitor int references Animal ON DELETE CASCADE
                                     ON UPDATE CASCADE
);

create table Especialidade(
  idEspecialidade int PRIMARY KEY,
  nome text constraint nome_especialidade_nn NOT NULL
);

create table Funcionario(
  nifFuncionario text PRIMARY KEY constraint nif_funcionario_c CHECK(LENGTH (nifFuncionario = 9)),
  nome text constraint nome_funcionario_nn NOT NULL,
  rua text,
  codigoPostal int,
  dataNascimento DATE default ('01-01-2003'),
  email text constraint email_funcionario_u UNIQUE,
  numeroTelefone text constraint numero_telefone_funcionario_nn NOT NULL
                      constraint numero_telefone_funcionario_u UNIQUE
                      constraint numero_telefone_funcionario_c CHECK(LENGTH (numeroTelefone = 9)),
  idEspecialidade int constraint id_especialidade_funcionario_nn NOT NULL references Especialidade ON DELETE CASCADE
                                                                                                   ON UPDATE CASCADE,
  idZoo int constraint id_zoo_funcionario_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                     ON UPDATE CASCADE
);

create table Sessao(
  idSessao int PRIMARY KEY,
  nome text constraint nome_sessao_nn NOT NULL,
  descricao text,
  idZoo int constraint id_zoo_sessao_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                ON UPDATE CASCADE
);

create table HorarioSessao(
  idHorarioSessao int PRIMARY KEY,
  horaInicio TIME,
  horaFim TIME,
  constraint horas_horario_sessao_c CHECK (horaFim > horaInicio)
);

create table SessaoHorarioSessao(
  idSessao int constraint id_sessao_sessao_horario_sessao_nn NOT NULL references Sessao ON DELETE CASCADE
                                                                                        ON UPDATE CASCADE,
  idHorarioSessao int constraint id_horario_sessao_sessao_horario_sessao_nn NOT NULL references HorarioSessao ON DELETE CASCADE
                                                                                                              ON UPDATE CASCADE,
  PRIMARY KEY (idSessao, idHorarioSessao)
);

create table Alimentacao(
  idAlimentacao int PRIMARY KEY,
  tipoAlimentacao text constraint tipo_alimentacao_nn NOT NULL default ('Plantas'),
  quantidadeDisponivel int constraint quantidade_disponivel_nn NOT NULL
                           constraint quantidade_disponivel_c CHECK(quantidadeDisponivel >= 0)
);

create table Habitat(
  idHabitat int PRIMARY KEY,
  area int constraint area_habitat_c CHECK (area > 0),
  numeroAnimais int constraint numero_animais_habitat_c CHECK (numeroAnimais >= 0),
  tipoHabitat text constraint tipo_habitat_nn NOT NULL,
  idZoo int constraint id_zoo_habitat_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                 ON UPDATE CASCADE
);

create table VisitanteZoo(
  nifVisitante text constraint visitante_visitante_zoo_nn NOT NULL references Visitante ON DELETE CASCADE
                                                                                        ON UPDATE CASCADE,
  idZoo int constraint id_zoo_visitante_animal_nn NOT NULL references Zoo ON DELETE CASCADE
                                                                          ON UPDATE CASCADE,
  PRIMARY KEY (nifVisitante, idZoo)
);

create table FuncionarioAnimalSessao(
  idAnimal int constraint id_animal_funcionario_animal_sessao_nn NOT NULL references Animal ON DELETE CASCADE
                                                                                            ON UPDATE CASCADE,
  nifFuncionario text constraint nif_funcionario_funcionario_animal_sessao_nn NOT NULL references Funcionario ON DELETE CASCADE
                                                                                                              ON UPDATE CASCADE,
  idSessao int constraint id_sessao_funcionario_animal_sessao_nn NOT NULL references Sessao ON DELETE CASCADE
                                                                                            ON UPDATE CASCADE,
  PRIMARY KEY (idAnimal, nifFuncionario, idSessao)
);

create table AnimalHabitat(
  idAnimal int constraint id_animal_animal_habitat_nn NOT NULL references Animal ON DELETE CASCADE
                                                                                 ON UPDATE CASCADE,
  idHabitat int constraint id_habitat_animal_habitat_nn NOT NULL references Habitat ON DELETE CASCADE
                                                                                    ON UPDATE CASCADE,
  PRIMARY KEY (idAnimal, idHabitat)
);

create table QuantidadeNecessaria(
  idAnimal int constraint id_animal_quantidade_necessaria_nn NOT NULL references Animal ON DELETE CASCADE
                                                                                        ON UPDATE CASCADE,
  idAlimentacao int constraint id_alimentacao_quantidade_necessaria_nn NOT NULL references Alimentacao ON DELETE CASCADE
                                                                                                       ON UPDATE CASCADE,
  quantidadeNecessaria int constraint quantidade_necessaria_nn NOT NULL
                           constraint quantidade_necessaria_c CHECK (quantidadeNecessaria >= 0),
  PRIMARY KEY (idAnimal, idAlimentacao)
);
