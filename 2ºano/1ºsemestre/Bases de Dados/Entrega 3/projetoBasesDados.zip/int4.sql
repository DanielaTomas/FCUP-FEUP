.mode columns
.headers on
.nullvalue NULL

select
(select count(*) from (select idServico from Servico
except
select idServico from Hotel
except
select idServico from Restaurante)) as numOutrosServicos,

(select count(*) from Hotel) as numHoteis,

(select count(*) from Restaurante) as numRestaurantes;
