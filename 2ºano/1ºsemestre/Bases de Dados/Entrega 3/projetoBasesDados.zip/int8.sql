.mode columns
.headers on
.nullvalue NULL


select distinct nomeZoo,idHabitat,tipoHabitat, ((Habitat.area*100)/Zoo.area) as percentagemOcupada
from Zoo,Habitat
where Zoo.idZoo = Habitat.idZoo
group by Habitat.idHabitat
order by tipoHabitat;
