.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

create view if not exists tratadores as
select nifFuncionario from Funcionario
where nifFuncionario in
(select Funcionario.nifFuncionario from Funcionario,Especialidade
where Funcionario.idEspecialidade = Especialidade.idEspecialidade and Especialidade.nome = 'tratador');


create trigger if not exists tratadorSessao
before update of nifFuncionario on FuncionarioAnimalSessao
for each row
begin
 select case
 when (select nifFuncionario from tratadores where tratadores.nifFuncionario) not in (select NEW.nifFuncionario)
 then raise(abort,'Apenas tratadores apresentam as sessoes.')
end;
end;
