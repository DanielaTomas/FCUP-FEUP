.mode columns
.headers on
.nullvalue NULL

create view if not exists numAnimaisTratador as
select nome,count(idAnimal) as numAnimais
from FuncionarioAnimalSessao natural join Funcionario
group by nome
order by nome;


select nome from numAnimaisTratador
where nome not in
(select nome from numAnimaisTratador where numAnimais <= 2)
order by nome;
