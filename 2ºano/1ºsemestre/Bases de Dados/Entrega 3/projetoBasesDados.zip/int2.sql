.mode columns
.headers on
.nullvalue NULL

create view if not exists sumQuantidadeNecessaria as
select idAlimentacao, quantidadeDisponivel, sum(quantidadeNecessaria) as total
from Alimentacao natural join QuantidadeNecessaria
group by idAlimentacao;


select distinct idAlimentacao, quantidadeDisponivel, total
from Alimentacao natural join sumQuantidadeNecessaria natural join QuantidadeNecessaria
where (quantidadeDisponivel <= total)
order by idAlimentacao;
