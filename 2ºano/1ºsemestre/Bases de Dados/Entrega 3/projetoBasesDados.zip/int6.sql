.mode columns
.headers on
.nullvalue NULL

create view if not exists lucroVendaBilhetes as
select idZoo, sum(preco) as lucro
from VisitanteZoo natural join Bilhete
group by idZoo;


select idZoo,lucro from lucroVendaBilhetes
where lucro = (select max(lucro) from lucroVendaBilhetes)
order by idZoo desc;
