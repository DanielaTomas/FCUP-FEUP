.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;


create trigger if not exists atualizaQuantidadeDisponivel
after insert on QuantidadeNecessaria
for each row
begin
  update Alimentacao
  set quantidadeDisponivel = quantidadeDisponivel - New.quantidadeNecessaria
  where Alimentacao.idAlimentacao = NEW.idAlimentacao;
end;
