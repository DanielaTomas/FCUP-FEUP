.mode columns
.headers on
.nullvalue NULL


select idAnimal, nome
from Animal
where (idade < 1 and idProgenitor is null)
order by nome;
