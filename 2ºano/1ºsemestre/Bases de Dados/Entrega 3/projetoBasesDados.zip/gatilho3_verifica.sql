.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

--estado inicial
select * from FuncionarioAnimalSessao;

insert into Zoo
  values(
    0001,
    'Zoo da Maia',
    5000,
    1274,
    '229442303',
    'Rua Estação',
    '4470-184',
    '10:00',
    '17:00',
    5,
    75000
);
insert into Animal(
  idAnimal,
  nome,
  idade,
  nomeComum,
  nomeCientifico,
  dataChegadaZoo,
  genero,
  idZoo,
  idProgenitor)
values (
  01,
  'Anabelle',
  3,
  'Alpaca',
  'Vicugna pacos',
  '23-04-2019',
  'Feminino',
  0001,
  NULL
  );
insert into Especialidade
    values(
      001,
      'tratador'
    );
insert into Especialidade
    values(
      002,
      'rececao'
    );
insert into Funcionario(
  nome,
  nifFuncionario,
  rua,
  codigoPostal,
  dataNascimento,
  email,
  numeroTelefone,
  idEspecialidade,
  idZoo
)
 values(
  'Israel Cerqueira Castilhos',
  '220689547',
  'Reta Manor',
  '5300-235',
  '1975-10-15',
  'israelcerqueiracastilhos@gmail.com',
  '918937373',
  001,
  0001
  );
  insert into Funcionario(
    nome,
    nifFuncionario,
    rua,
    codigoPostal,
    dataNascimento,
    email,
    numeroTelefone,
    idEspecialidade,
    idZoo
  )
   values(
    'Maria Oliveira',
    '220111547',
    'Rua Sao Jose',
    '4300-235',
    '1990-11-18',
    'mariaoliveira@gmail.com',
    '918931122',
    002,
    0001
    );
insert into Sessao
  values(
    100,
    'Apresentação da Alpaca',
    'Dar a conhecer os comportamentos na vida da Alpaca',
    0001
);
insert into FuncionarioAnimalSessao
  values(
    01,
    '220689547',
    100
);
update FuncionarioAnimalSessao set nifFuncionario = '220111547' where FuncionarioAnimalSessao.nifFuncionario = '220689547';

--nao atualiza
select * from FuncionarioAnimalSessao;
