.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

--estado inicial
select * from Funcionario;

insert into Zoo
  values(
    0001,
    'Zoo da Maia',
    5000,
    1274,
    '229442303',
    'Rua Estação',
    '4470-184',
    '10:00',
    '17:00',
    5,
    75000
);
insert into Especialidade
  values(
    002,
    'rececao'
  );

--funcionario com menos de 18 anos
insert into Funcionario
  values(
  'Joao Silva',
  '220689028',
  'Rua Albatroz',
  '5300-232',
  'now',
  'joaosilva@gmail.com',
  '918937321',
  002,
  0001
  );

--nao insere
select * from Funcionario;
