.mode columns
.header on
.nullvalue NULL
Pragma Foreign_Keys = on;

drop trigger if exists atualizaQuantidadeDisponivel;
