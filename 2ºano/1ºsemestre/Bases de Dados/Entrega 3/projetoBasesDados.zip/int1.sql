.mode columns
.headers on
.nullvalue NULL

select tipoAlimentacao, avg(quantidadeNecessaria) as "media(quantidadeNecessaria)"
from (Alimentacao natural join QuantidadeNecessaria)
group by tipoAlimentacao
order by "media(quantidadeNecessaria)" desc;
