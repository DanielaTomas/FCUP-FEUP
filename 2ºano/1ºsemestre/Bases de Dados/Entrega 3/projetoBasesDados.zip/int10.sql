.mode columns
.headers on
.nullvalue NULL


select nifFuncionario, nome
from Funcionario

INTERSECT

select nifVisitante, nome
from Visitante
order by nome asc;
