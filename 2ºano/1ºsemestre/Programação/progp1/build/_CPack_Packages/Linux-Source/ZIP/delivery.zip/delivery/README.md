
# Trabalho de programação

## Grupo
up202004946, Daniela dos Santos Tomás

up202005977, Francisca Correia de Moura Sineiro Andrade

## Tarefas realizadas
Conseguimos realizar todas as tarefas propostas.


