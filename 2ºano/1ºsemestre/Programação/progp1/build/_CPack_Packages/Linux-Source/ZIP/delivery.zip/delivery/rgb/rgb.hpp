//! @file rgb.hpp
#ifndef __rgb_hpp__
#define __rgb_hpp__

#include <rgb/color.hpp>
#include <rgb/image.hpp>
#include <rgb/script.hpp>
#include <png/png.hpp>

#endif
