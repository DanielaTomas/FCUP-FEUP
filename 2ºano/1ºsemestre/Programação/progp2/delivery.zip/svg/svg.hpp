//! @file svg.hpp
#ifndef __svg_svg_hpp__
#define __svg_svg_hpp__

#ifdef TEACHER_VERSION
#include <svg/elements-s.hpp>
#else
#include <svg/elements.hpp>
#endif
#include <svg/svg_to_png.hpp>

#endif

