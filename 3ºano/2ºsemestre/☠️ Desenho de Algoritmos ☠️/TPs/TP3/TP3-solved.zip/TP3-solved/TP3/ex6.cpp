// By: Gonçalo Leão

#include "exercises.h"

#include "MSTTestAux.h"
#include "../data_structures/UFDS.h"

std::vector<Vertex *> GreedyGraph::kruskal() {
    if (vertexSet.empty()) {
        return this->vertexSet;
    }

    // Give a unique id per vertex (to use them with the UFDS)
    UFDS ufds(vertexSet.size());
    {
        int id = 0;
        for (auto v: vertexSet) {
            v->setId(id++);
        }
    }

    // Initialize the list of all edges
    std::vector<Edge *> allEdges;
    for (auto v: vertexSet) {
        for (auto e: v->getAdj()) {
            e->setSelected(false);
            if (e->getOrig()->getId() < e->getDest()->getId()) { // one edge per pair of symmetric edges
                allEdges.push_back(e);
            }
        }
    }

    // Sort the list of edges by increasing weights
    sort(allEdges.begin(), allEdges.end(), [](Edge *a, Edge *b) { return a->getWeight() < b->getWeight(); });

    // Process edges in order by increasing weights, and select relevant edges
    unsigned selectedEdges = 0;
    for (auto e: allEdges) {
        auto orig = e->getOrig();
        auto dest = e->getDest();

        if (!ufds.isSameSet(orig->getId(), dest->getId())) {
            // link the sets
            ufds.linkSets(orig->getId(), dest->getId());

            // mark the edge (in both directions) as selected
            e->setSelected(true);
            e->getReverse()->setSelected(true);

            // if no more edges needed, stop
            if (++selectedEdges == vertexSet.size() - 1) {
                break;
            }
        }
    }

    // Reassign the "path" field to make a directed tree rooted in vertex 0,
    // based on the selected edges and a depth-first search visit.
    for (auto v: vertexSet) {
        v->setVisited(false);
    }
    vertexSet[0]->setPath(nullptr);

    // Compute the path fields to read the spanning tree
    dfsKruskalPath(vertexSet[0]);

    return vertexSet;
}

void GreedyGraph::dfsKruskalPath(Vertex *v) {
    v->setVisited(true);
    for (auto e : v->getAdj()) {
        if (e->isSelected() && !e->getDest()->isVisited()) {
            e->getDest()->setPath(e);
            dfsKruskalPath(e->getDest());
        }
    }
}

/// TESTS ///
#include <gtest/gtest.h>
#include <chrono>

TEST(TP3_Ex6, test_kruskal) {
    GreedyGraph graph = createMSTTestGraph();
    std::vector<Vertex *> res = graph.kruskal();

    std::stringstream ss;
    for(const auto v : res) {
        ss << v->getId() << "<-";
        if ( v->getPath() != nullptr ) {
            ss << v->getPath()->getOrig()->getId();
        }
        ss << "|";
    }
    std::cout << ss.str() << std::endl;

    EXPECT_TRUE(isSpanningTree(res));
    EXPECT_EQ(spanningTreeCost(res), 11);
}

TEST(TP3_Ex6, test_performance_kruskal) {
    //Change these const parameters as needed
    const int MIN_SIZE = 10;
    const int MAX_SIZE = 30; //Try with 100
    const int STEP_SIZE = 10;
    const int N_REPETITIONS = 50;
    for (int n = MIN_SIZE; n <= MAX_SIZE; n += STEP_SIZE) {
        GreedyGraph g;
        generateRandomGridGraph(n, g);
        auto start = std::chrono::high_resolution_clock::now();
        for (int i = 1; i <= N_REPETITIONS; i++)
            g.kruskal();
        auto finish = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();
        std::cout << "Processing grid (Kruskal) " << n << " x " << n << " average time (milliseconds)=" << (elapsed / N_REPETITIONS) << std::endl;
    }
}
