// By: Gonçalo Leão

#include "exercises.h"

#include <algorithm>

// Time: O(N*log(N)), Space: O(N), where N is the number of tasks
double minimumAverageCompletionTime(std::vector<unsigned int> tasks, std::vector<unsigned int> &orderedTasks) {
    std::sort(tasks.begin(),tasks.end());
    orderedTasks = tasks;
    unsigned int latestTime = 0;
    double sumEndTimes = 0.0;
    for(size_t i = 0; i < orderedTasks.size(); i++) {
        latestTime += orderedTasks[i];
        sumEndTimes += latestTime;
    }
    return sumEndTimes / orderedTasks.size();
}

/// TESTS ///
#include <gtest/gtest.h>
#include <gmock/gmock.h>

TEST(TP3_Ex3, taskOrdering) {
    std::vector<unsigned int> tasks = {15, 8, 3, 10};
    std::vector<unsigned int> orderedTasks;
    double averageTime = minimumAverageCompletionTime(tasks, orderedTasks);
    EXPECT_EQ(orderedTasks.size(), 4 );
    EXPECT_NEAR(averageTime, 17.75, 0.00001);
    EXPECT_THAT(orderedTasks,  ::testing::ElementsAre(3,8,10,15));
}