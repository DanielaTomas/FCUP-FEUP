// By: Gonçalo Leão

#include "exercises.h"

bool Activity::operator==(const Activity &a2) const {
    return start == a2.start && finish == a2.finish;
}

bool Activity::overlaps(const Activity &a2) const {
    return (start < a2.finish) && (a2.start < finish);
}

#include <iostream>

void activitySelectionBTRec(std::vector<Activity> A, std::vector<Activity> curSolution, std::vector<Activity> &bestSolution) {
    if(A.empty()) {
        if(curSolution.size() > bestSolution.size()) {
            bestSolution = curSolution;
        }
        return;
    }

    // Get the next activity
    Activity nextAct = A.at(A.size() - 1);
    A.pop_back();

    // Try including the next activity
    bool overlapsOne = false;
    for(const auto act: curSolution) {
        if(nextAct.overlaps(act)) {
            overlapsOne = true;
            break;
        }
    }
    if(!overlapsOne) {
        std::vector<Activity> nextSolution = curSolution;
        nextSolution.push_back(nextAct);
        activitySelectionBTRec(A, nextSolution, bestSolution);
    }

    // Don't try including the next activity
    activitySelectionBTRec(A, curSolution, bestSolution);
}

std::vector<Activity> activitySelectionBT(std::vector<Activity> A) {
    std::vector<Activity> curSol;
    std::vector<Activity> V;
    activitySelectionBTRec(A, curSol, V);
    return V;
}

/// TESTS ///
#include <gtest/gtest.h>
#include <gmock/gmock.h>

bool noOverlaps(const std::vector<Activity> &acts) {
    for(unsigned int i = 0; i < acts.size(); i++) {
        Activity A1 = acts.at(i);
        for(unsigned int j = i + 1; j < acts.size(); j++) {
            Activity A2 = acts.at(j);
            if(A1.overlaps(A2)) return false;
        }
    }
    return true;
}

TEST(TP7_Ex4, activityScheduling) {
    std::vector<Activity> A = {{10,20}, {30, 35}, {5, 15}, {10, 40}, {40, 50}};
    std::vector<Activity> V = activitySelectionBT(A);
    EXPECT_EQ(V.size(), 3 );
    EXPECT_EQ(noOverlaps(V), true);
}