#include "exercises.h"

void createNetwork(IntroGraph &graph);