#include "exercises.h"

#include <cmath>

Result nearestPointsBF(std::vector<Point> &vp) {
    Result res;
    // TODO
    return res;
}

/// TESTS ///
#include "gtest/gtest.h"

TEST(TP2_Ex5, testNPBF) {
    testNearestPoints(nearestPointsBF, "Brute force");
}